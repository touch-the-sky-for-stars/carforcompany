#ifndef __PWM_H
#define __PWM_H
#include "sys.h"
void PWM_Init_TIM1(uint16_t psc,uint16_t  per);
#endif
