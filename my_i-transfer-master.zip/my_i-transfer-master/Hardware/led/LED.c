#include "stm32f10x.h"                  // Device header
/**
 * @brief LED��ʼ��
 * @param ��
 * @retval ��
 */

void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitTypeDef GPIO_Initstructure;
	GPIO_Initstructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_Initstructure.GPIO_Pin=GPIO_Pin_3|GPIO_Pin_2;
	GPIO_Initstructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_Initstructure);
	GPIO_SetBits(GPIOC,GPIO_Pin_3|GPIO_Pin_2);
}

/**
 * @brief LED״̬����
 * @param 1 or 0��1Ϊ����2Ϊ��
 * @retval ��
 */

void LED1(unsigned char a)
{
	a == 1 ? GPIO_ResetBits(GPIOC, GPIO_Pin_3) : GPIO_SetBits(GPIOC, GPIO_Pin_3);
}

void LED2(unsigned char a)
{
	a == 1 ? GPIO_ResetBits(GPIOC, GPIO_Pin_2) : GPIO_SetBits(GPIOC, GPIO_Pin_2);
}