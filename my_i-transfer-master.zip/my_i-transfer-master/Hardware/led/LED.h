#ifndef __LED_H
#define __LED_H
void LED_Init();
void LED1(unsigned char a);
void LED2(unsigned char a);
#endif