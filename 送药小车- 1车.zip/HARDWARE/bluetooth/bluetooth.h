#ifndef _BLUETOOTH_H
#define _BLUETOOTH_H

void bluetooth_U3_Init();
void bluetooth_IO_Init();

#endif // !_BLUETOOTH_H