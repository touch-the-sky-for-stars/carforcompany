/* PC4,PC5,PF5,PF7用作转向引脚，PA0/TIM5,PF8/TIM13用作PWM输出 */
#include "stm32f4xx.h"
#include "sys.h"
#include "stm32f4xx_rcc.h"
#include "dianji.h"
#include "stm32f4xx_tim.h"
#include "delay.h"
#include "duoji.h"
#define INT1 PCout(4)
#define INT2 PCout(5)
#define INT3 PFout(5)
#define INT4 PFout(7)

/* 电机控制引脚：PC4,PC5,PC9,PF5,PF7,PF10 */
void dianji_IO_Init()
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE); //??GPIOA??

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; //??50MHz
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;     //??????
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;     //??
    GPIO_Init(GPIOC, &GPIO_InitStructure);             //???PA9,PA10         //???PA9,PA10

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE); //??GPIOA??

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; //??50MHz
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;     //??????
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;       //??
    GPIO_Init(GPIOF, &GPIO_InitStructure);             //???PA9,PA10
}
 


/* 电机PWM初始化，所用引脚为：PA0,PF8(TIM5,TIM13) */
void dianji_PWM_Init(u16 per, u16 psc)
{
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;

	/*使能TIM1时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);
	
	/*使能GPIOA*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);
	
	//复用：
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource8,GPIO_AF_TIM1); //GPIOA8复用为定时器1

	GPIO_PinAFConfig(GPIOA,GPIO_PinSource11,GPIO_AF_TIM1); //GPIOA8复用为定时器1
	/*配置GPIO*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11;           //GPIOF9
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;        //复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;	//速度100MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;      //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;        //上拉
	GPIO_Init(GPIOA,&GPIO_InitStructure);              //初始化PF9
	
	
	
	/*初始化定时器参数*/
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;//选择时钟分频为1分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;//选择计数模式为向上计数
	TIM_TimeBaseInitStructure.TIM_Period = per;//配置周期（ARR自动重装器的值）
	TIM_TimeBaseInitStructure.TIM_Prescaler = psc;//配置PSC预分频器的值
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;//重复计数器的值，高级计数器才需配置
	TIM_TimeBaseInit(TIM1,&TIM_TimeBaseInitStructure);
	
	TIM_ClearFlag(TIM1,TIM_FLAG_Update);//先清除标志位，避免刚初始化就进入中断
	
	/*初始化PWM参数*/
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;//选择PWM1模式
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;//输出极性：低电平有效
	TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;//使能
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;
	TIM_OC1Init(TIM1,&TIM_OCInitStructure);

	TIM_OC4Init(TIM1,&TIM_OCInitStructure);
	
	/*使能TIMX在CCRX上的预装载寄存器*/
	TIM_OC1PreloadConfig(TIM1,TIM_OCPreload_Enable);

	TIM_OC4PreloadConfig(TIM1,TIM_OCPreload_Enable);
	
	TIM_CtrlPWMOutputs(TIM1,ENABLE);
	
	/*使能TIMX在ARR上的预装载寄存器允许位*/
	TIM_ARRPreloadConfig(TIM4,ENABLE);
	
	/*开启定时器*/
	TIM_Cmd(TIM1,ENABLE);
}


/* len的范围在1000以内 */


void stop()
{
    INT3 = 0;
    INT4 = 0;
    INT1 = 0;
    INT2 = 0;
}

void xunji()
{


}
void zhixingguoluokou()
{ PCout(4)=0;
	PCout(5)=1;
	PFout(5)=0;
	PFout(7)=1;
	zhixing();
	delay_ms(300);
}

void zhixing()
{

  TIM_SetCompare1(TIM1, 680);
  TIM_SetCompare4(TIM1, 450);
}

void zuozhuan()
{
//左转
  PCout(5) = 1;
//	Change_Target(0,58);
	TIM_SetCompare4(TIM1,685);
	delay_ms(600);
	//PFout(7) = 1;

}
void youzhuan()
{
//右转	
	  PFout(7) = 1;
	TIM_SetCompare1(TIM1, 650);
	delay_ms(600);

}

