#ifndef _DUOJI_H
#define _DUOJI_H

#include "sys.h"


void Change_Target(int t_l,int t_r);
void TIM4_Init(u16 arr,u16 psc);
void Encoder_Init(void);

#endif // DEBUG