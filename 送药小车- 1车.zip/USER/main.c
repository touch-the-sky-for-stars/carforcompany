//1��
#include "stm32f4xx.h"
#include "sys.h"
#include "delay.h"
#include "duoji.h"
#include "dianji.h"
#include "bluetooth.h"
#include "to_openmv.h"
#include "hongwai.h"
#include "usart.h"
#include "stdbool.h"
#include "led.h"



#define guangdian_IO PBin(10) //װ����ҩƷ��hongwai_IO = 0
#define Start 0
#define Wait 5




#define xunji 11
#define Finish 16

int j=0;
signed char bluetooth = 0;
uint16_t temp = 0;
char state = 0;
char flag = 0; //�Ƿ��Ѿ�ʶ��Ҫȥ�Ĳ�����
signed char rec_flag = 0;
u16 openmv_rec[4] = {0};
signed char i = 0;
uint8_t num=0;
bool jieduan=0;
int xincheng[10];
int jilu=0;
int tingzhi_flag=0;
int lukoujishu=0;
int bluetooth_buff=0;
int lanya_send=1;
int twocheqidong=1;
void zuozhuanwan()
{							
							zhixing();
							delay_ms(300);
							stop();
							delay_ms(100);
							zuozhuan();
							stop();
							delay_ms(200);
							PCout(5)=1;
							PFout(7)=1;

							USART_SendData(UART5,'3');
//	while(USART_GetFlagStatus(UART5,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
							
}

void youzhuanwan()
{			
							zhixing();
							delay_ms(300);
							stop();
							delay_ms(100);
							youzhuan();
							stop();
							delay_ms(200);
							PCout(5)=1;
							PFout(7)=1;

							USART_SendData(UART5,'3');
//	while(USART_GetFlagStatus(UART5,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
						
}

void turn_r()
{

	  PFout(5) = 0;
    PFout(7) = 1;
	  PCout(4) = 1;
    PCout(5) = 0;
		Change_Target(465,430);
		delay_ms(1100);
			stop();
		
}

void shibieshuzhizhunbei()
{
	  PFout(5) = 1;
    PFout(7) = 0;
	  PCout(4) = 1;
    PCout(5) = 0;
		Change_Target(535,500);
	delay_ms(100);
			stop();
}
void uart_5_chuli()
{
	int pianzhuanjiaodu=0;
		switch(openmv_rec[1])
				{	
					case 0:
							flag=1;
							num=openmv_rec[2];
							LED1=0;
			  
						break;
						
					case 1:
						
							state = xunji;
							xincheng[jilu++]=1;
							PFout(7)=1;
							PCout(5)=1;
							zuozhuanwan();
						break;
					
					case 2:	

							state = xunji;
							xincheng[jilu++]=2;
							PFout(7)=1;
							PCout(5)=1;
							youzhuanwan();
						break;
					
					case 3:
							stop();
							if(jieduan==0)
							{
								lukoujishu++;
							
							switch(lukoujishu)
							{
								case 1:
											switch(num)
											{
												case 1:
														state = xunji;
														xincheng[jilu++]=1;
														stop();
														PFout(7)=1;
														PCout(5)=1;
														zuozhuanwan();
												break;
												
												case 2:
														state = xunji;
														xincheng[jilu++]=2;
														stop();
														PFout(7)=1;
														PCout(5)=1;
														youzhuanwan();
													break;
												
												default:
														zhixingguoluokou();
														xincheng[jilu++]=3;
														USART_SendData(UART5,'3');
													break;
											}
								break;
											
								case 3:
											state = xunji;
											xincheng[jilu++]=1;

										PFout(7)=1;
										PCout(5)=1;
										zhixing();
										delay_ms(150);
										stop();
											zuozhuanwan();
										break;

							default:
									stop();
									delay_ms(100);
									shibieshuzhizhunbei();
									USART_SendData(UART5,'2');
								
									break;
								}
							}
							else
							{			
										state = xunji;
										jilu--;
								switch(xincheng[jilu])
								{
									case 1:
										PFout(7)=1;
										PCout(5)=1;
										zhixing();
										delay_ms(150);
										stop();
										youzhuanwan();
									break;
									
									case 2:
										PFout(7)=1;
										PCout(5)=1;
										zhixing();
										delay_ms(150);
										stop();
										zuozhuanwan();
										break;
									
									case 3:
										zhixingguoluokou();
									delay_ms(400);
										USART_SendData(UART5,'3');
									if(jilu==0)
									LED1=0;
					//		while(USART_GetFlagStatus(UART5,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
										break;
									
									default:
										break;
								}
								if(twocheqidong==1)
								{
									twocheqidong=0;
									USART_SendData(USART3,'0');
								}
								break;
							}
								break;
					
						case 4:
							if(lukoujishu==4)
							{
								xincheng[2]=2;
								lukoujishu=3;
								turn_r();
								PFout(7)=1;
								PCout(5)=1;
							}
							else
							{
								zhixingguoluokou();
								delay_ms(250);
								xincheng[jilu++]=3;
							}
							USART_SendData(UART5,'3');
							break;
							
						case 5:
							pianzhuanjiaodu=openmv_rec[2];
							Change_Target(485-(pianzhuanjiaodu-52)*7,420+(pianzhuanjiaodu-52)*7);
						break;
				
						case 6:
							stop();
							if(tingzhi_flag>=1)
							{
								stop();
								state=Finish;
							}
							else
							{
							tingzhi_flag++;
								state=Wait;
							}
							break;
				}
}

void All_Init()
{	  //uart_init(115200);
    delay_init(168);
		LED_Init();
    hongwai_IO_Init();
    dianji_IO_Init();
    dianji_PWM_Init(1000-1, 84 - 1);
		bluetooth_U3_Init();
    openmv_U5_Init();
	//	Encoder_Init();
		LED1=1;
}



int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    All_Init();

		state=Start;
		PFout(5) = 0;
		PFout(7) = 1;
		PCout(4) = 0;
		PCout(5) = 1;

    while (1)
    { 
			
	
        switch (state)
        {
        case Start:
            while(flag == 0); //�Ѿ�ʶ�𵽲�����
						
            while (flag == 1)
            {
							
                if (guangdian_IO == 1)
                {
										delay_ms(1000);
                    if (guangdian_IO == 1)
										{			
												state=xunji;
												LED1=1;	
												USART_SendData(UART5,'3');
                        break;
										}
                }
            }
            break;
						
				case xunji:
					break;

        case Wait:
				//	USART_SendData(UART5,jilu+'0');
						while(1)
							{
									if(bluetooth_buff==1	&&	lanya_send==1)
									{
													lanya_send=0;
													if(lukoujishu>2)
													{
															if(xincheng[2]==1)
																USART_SendData(USART3,'3');
															else
																USART_SendData(USART3,'4');
													}
													else
													{
																if(xincheng[1]==1)
																USART_SendData(USART3,'1');
															else
																USART_SendData(USART3,'2');
													}
													while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);
									}
									if (guangdian_IO == 0)
								{
										delay_ms(1000);
										if (guangdian_IO == 0)
										{
											state=xunji;
											jieduan=1;
											turn_r();
											PFout(7) = 1;
											PCout(5) = 1;	
											if(jilu>=3)
													USART_SendData(UART5,'4');
											else
											USART_SendData(UART5,'3');
											while(USART_GetFlagStatus(UART5,USART_FLAG_TC)!=SET);
											break;
										}
								}
							}
            break;
							
        case Finish:
            stop();
            state = Start;
            break;
        default:
            break;
        }
			}	
}
/* �������� */
//  1 che
void USART3_IRQHandler()
{
    if (USART_GetITStatus(USART3, USART_IT_RXNE)!=RESET)
    {
        bluetooth = USART_ReceiveData(USART3);
        //USART_SendData(USART1, bluetooth);
        if (bluetooth == '0')
        {
           bluetooth_buff=1;
			 		LED0=0;
        
				}
    }
    USART_ClearITPendingBit(USART3, USART_IT_RXNE);
}

/* openmv���� */
void UART5_IRQHandler()
{
	if (USART_GetITStatus(UART5, USART_IT_RXNE)!=RESET)
	{
		signed char temp = USART_ReceiveData(UART5);
		if (temp ==0x2C)
		{

				rec_flag = 1;
				i = 1;
		}
		else if (rec_flag == 1)
		{
				if (temp ==0x5B)
				{
						openmv_rec[i] = 0x5B;
						uart_5_chuli();
						rec_flag=0;

				}
				else
				{
						openmv_rec[i] = temp;
						i++;
				}

			}
		USART_ClearITPendingBit(UART5,USART_IT_RXNE);  			
	}

}


/* ����ͨ�� */
void USART1_IRQHandler()
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE))
    {
        temp = USART_ReceiveData(USART1);
        USART_SendData(USART3, temp);
    }
    USART_ClearITPendingBit(USART3, USART_IT_RXNE);
}
