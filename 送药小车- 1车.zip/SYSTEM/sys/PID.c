#include "PID.h"
 
PID pid;
void PID_Init(float p,float d)            
{
    pid.choose_model = MODEL_PD;    
    pid.T=1000;                //��������    
    pid.Sv=7.5;               
    pid.Kp=p;               
    pid.Ki=1;            //����ʱ�䳣��
    pid.Kd=d;            //΢��ʱ�䳣��
	 pid.OUT = 0.0;
    pid.OUT0=1000;
    pid.Tdata = 1000;	
    pid.max = 900;
	 pid.min = 100;
	 pid.Ek = 0;
	 pid.Ek_1 = 0;
	 pid.k = 0;
	 pid.dir = 0;
}
    
char PID_Calc(float Pv,float w)  //pid����
{
    float DelEk;            //���κ��ϴ�ƫ��֮��
    float out;
 
    if(pid.Tdata < pid.T)  //��С��������δ��
     {
        return 0;
     }
     
	 pid.Pv = Pv;
    pid.Ek=pid.Sv-pid.Pv; 		
    pid.Pout=pid.Kp*pid.Ek;          //�������
                   
    DelEk=pid.Ek-pid.Ek_1;
    if((pid.Ek * pid.Ek_1) < 0.0)
    {
       pid.SEk = 0;
    }
    pid.SEk += pid.Ek;    //��ʷƫ��֮��	
    pid.Iout=pid.Ki*pid.SEk;  //�������
    pid.Dout=pid.Kd*w; //΢�����
 
     switch(pid.choose_model)
     {
         case MODEL_P: out=pid.Pout; break;
         
         case MODEL_PI: out=pid.Pout+ pid.Iout; break;
                 
         case MODEL_PID: out=pid.Pout+ pid.Iout+ pid.Dout; break;
			 
			case MODEL_PD: out=pid.Pout+ pid.Dout; break;
     }
     if(out > 0) {pid.dir = 3;}
	  else {pid.dir = 4;out = -out;}
     if(out>pid.max)       
     {
        pid.OUT=pid.max;
     }
     else if(out<pid.min)      
     {
        pid.OUT=pid.min; 
     }
     else 
     {
        pid.OUT=out;
     }
     pid.Ek_1=pid.Ek;  //����ƫ�� 
     
     return pid.dir;		 
}