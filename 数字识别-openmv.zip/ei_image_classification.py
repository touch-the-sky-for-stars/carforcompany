import sensor, image, time, os, tf, uos, gc, binascii,math,ustruct
from pyb import UART
from pyb import LED
import json
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.set_windowing((240, 240))
sensor.skip_frames(time=2000)
net0 = None
labels0 = None
net1 = None
labels1 = None
uart = UART(3, 115200)
uart.init(115200, bits=8, parity=None, stop=1)
def sending_data(cx,cy):
    global uart;
    data = ustruct.pack("<bbhhhhb",
                   0x2C,
                   int(cx),
                   int(cy),
                   0x5B)
    #

    uart.write(data);
try:
    net0 = tf.load("trained0.tflite", load_to_fb=uos.stat('trained0.tflite')[6] > (gc.mem_free() - (64*1024)))
except Exception as e:
    print(e)
    raise Exception('Failed to load "trained0.tflite", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')
try:
    labels0 = [line.rstrip('\n') for line in open("labels0.txt")]
except Exception as e:
    raise Exception('Failed to load "labels0.txt", did you copy the .tflite and labels0.txt file onto the mass-storage device? (' + str(e) + ')')
try:
    net1 = tf.load("trained1.tflite", load_to_fb=uos.stat('trained1.tflite')[6] > (gc.mem_free() - (64*1024)))
except Exception as e:
    print(e)
    raise Exception('Failed to load "trained1.tflite", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')
try:
    labels1 = [line.rstrip('\n') for line in open("labels1.txt")]
except Exception as e:
    raise Exception('Failed to load "labels1.txt", did you copy the .tflite and labels1.txt file onto the mass-storage device? (' + str(e) + ')')


LED(3).on()
openmv_flag=1
shangyichishuzhi=0
shuzhi_flag=0
zhixing_flag=0
che_flag=0
zhongdian_flag=0
t_flag=0
RED_THRESHOLD = [(200,10,10),(255,50,50)]
BLACK_THRESHOLD = [(0, 48, -58, 49, -36, -1)]
ROIS = [(0, 15, 160, 25, 0.9),(0, 40, 160, 25, 0.6),(0, 65, 160, 30, 0.6)]
ROI =  [(10,0,30,50),(110,0,30,50)]
ROIH =  [(0,0,30,40),(120,0,35,45),(50,0,60,50)]
a=0
b=0
clock = time.clock()
while(True):
    #img = sensor.snapshot()
    while(openmv_flag==0):
       #img = sensor.snapshot()
       if (uart.any()):
          B = uart.read()
          print(B)
          if B==b'1':
            openmv_flag=1
          if B==b'2':
            openmv_flag=2
          if B==b'3':
            openmv_flag=3
          if B==b'4':
            openmv_flag=3
            che_flag=4
    while(openmv_flag==1):
        clock.tick()
        img = sensor.snapshot()
        for obj in net0.classify(img, min_scale=1.0, scale_mul=0.8, x_overlap=0.5, y_overlap=0.5):
            img.draw_rectangle(obj.rect())
            predictions_list = list(zip(labels0, obj.output()))
            for i in range(len(predictions_list)):
                if predictions_list[i][1]>0.8:
                    print("%s = %f " % (predictions_list[i][0], predictions_list[i][1]))
                    if shuzhi_flag>2:
                         num=int(predictions_list[i][0])
                         data = bytearray([0x2C,0,num,0x5B])
                         uart.write(data)
                         print(num)
                         print(data)
                         openmv_flag=0
                         shuzhi_flag=0
                         print("%s = %f" % (predictions_list[i][0], predictions_list[i][1]))
                    else:
                        if shuzhi_flag==0:
                            shangyichishuzhi=predictions_list[i][0]
                        if shangyichishuzhi==predictions_list[i][0]:
                            shuzhi_flag+=1
                        else:
                            shuzhi_flag=0
                        shangyichishuzhi=predictions_list[i][0]
    while(openmv_flag==2):
        clock.tick()
        img = sensor.snapshot()
        roiL=(0,20,80,80)
        roiR=(80,20,80,80)
        for obj in net1.classify(img,roiL, min_scale=1.0, scale_mul=0.8, x_overlap=0.5, y_overlap=0.5):
            img.draw_rectangle(obj.rect())
            predictions_list = list(zip(labels1, obj.output()))
            for i in range(len(predictions_list)):
                if predictions_list[i][1]>0.8:
                    print("111   %s = %f " % (predictions_list[i][0], predictions_list[i][1]))
                    if int(predictions_list[i][0])==num:
                         data = bytearray([0x2C,1,num,0x5B])
                         print(data)
                         print("%s = %f" % (predictions_list[i][0], predictions_list[i][1]))
                         openmv_flag=0
                         print("666")
                         uart.write(data)
                    else:
                     a=1
        for obj in net1.classify(img,roiR, min_scale=1.0, scale_mul=0.8, x_overlap=0.5, y_overlap=0.5):
                 img.draw_rectangle(obj.rect())
                 predictions_list = list(zip(labels1, obj.output()))
                 for i in range(len(predictions_list)):
                       if predictions_list[i][1]>0.8:
                             print("222   %s = %f " % (predictions_list[i][0], predictions_list[i][1]))
                             if int(predictions_list[i][0])==num:
                                  data = bytearray([0x2C,2,num,0x5B])
                                  print(data)
                                  print("%s = %f" % (predictions_list[i][0], predictions_list[i][1]))
                                  openmv_flag=0
                                  print("666")
                                  uart.write(data)
                             else:
                                b=1
        c=a+b
        if(c==2):
            data = bytearray([0x2C,4,0,0x5B])
            uart.write(data)
            print("000")
            openmv_flag=0
        a=0
        b=0
    while(openmv_flag==3):
         clock.tick()
         img = sensor.snapshot()
         #--------------------------------------- 判断直线角度 ------------------------------------------------
         centroid_sum = 0
         dx = 0
         weight_sum=0
         for r in ROIS:#在划分的上半图像中找红线
             blobs = img.find_blobs(RED_THRESHOLD, roi=r[0:4], merge=True) # r[0:4]是感兴趣区域的矩形元组.
             if blobs:
                 # Find the blob with the most pixels.
                 largest_blob = max(blobs, key=lambda b: b.pixels()) # 在blobs中找最大像素值
                 img.draw_rectangle(largest_blob.rect())
                 # 将此区域的像素数最大的颜色块画矩形和十字形标记出来
                 img.draw_cross(largest_blob.cx(),largest_blob.cy())
                 Moban_flag=1
                 #print(largest_blob.cx())
                 centroid_sum += (80-largest_blob.cx())*r[4] # 最大值像素点的x坐标*权值 与 图像中心线的偏差值
                 weight_sum = weight_sum + r[4] #权值综合
                 #计算centroid_sum，centroid_sum等于每个区域的最大颜色块的中心点的x坐标值乘本区域的权值
         if blobs:
             if weight_sum:
                      center_pos = (centroid_sum / weight_sum)
                      weight_sum = 0
             deflection_angle = 0
             ns = center_pos/60  # QQVGA 160x120.
             deflection_angle = -math.atan(ns)
             deflection_angle = math.degrees(deflection_angle)
             deflection_angle = 0 - int(deflection_angle)
             print(deflection_angle)
             data = bytearray([0x2C,5,int(deflection_angle)+52,0x5B])
             uart.write(data)
         else:
                openmv_flag=0;
                data = bytearray([0x2C,6,0,0x5B])
                print(data)
                uart.write(data)
         blobs1 = img.find_blobs(RED_THRESHOLD, roi=ROI[0],area_threshold=150, merge=True)
         blobs2 = img.find_blobs(RED_THRESHOLD, roi=ROI[1], area_threshold=150,merge=True)
         if che_flag==4:
             blobs1 = img.find_blobs(RED_THRESHOLD, roi=ROIH[0],area_threshold=150, merge=True)
             blobs2 = img.find_blobs(RED_THRESHOLD, roi=ROIH[1], area_threshold=150,merge=True)
             blobs3 = img.find_blobs(RED_THRESHOLD, roi=ROIH[2], area_threshold=150,merge=True)
             if blobs1:
                 print("+1111")
                 if blobs3:
                    print("+1111111111")
                    #img.draw_rectangle(blobs1.arect())
                    openmv_flag=0
                    if t_flag==1:
                        che_flag=0
                    t_flag=1
                    data = bytearray([0x2C,3,0,0x5B])
                    uart.write(data)
             else:
                  if blobs2:
                    print("+222")
                    if blobs3:
                        print("+2222222")
                        #img.draw_rectangle(blobs1.arect())
                        openmv_flag=0
                        if t_flag==1:
                             che_flag=0
                        t_flag=1
                        data = bytearray([0x2C,3,0,0x5B])
                        uart.write(data)
         else:
            if blobs1:
                if blobs2:
                     print("+")
                     openmv_flag=0
                     data = bytearray([0x2C,3,0,0x5B])
                     print(data)
                     uart.write(data)
