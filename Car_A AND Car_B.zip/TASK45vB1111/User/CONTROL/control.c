#include "./CONTROL/control.h"

// ע���������ͷ��ʱ
int TUNEM180_NUM = 0;    // ��¼���ּ�����Ӱ��

void kong(void){}
u8 Start_Xue_Xi_falg[5] = {0,0,0,0,0};
void Start_Xue_Xi(void)
{
        if(!Start_Xue_Xi_falg[0] && TUNEM180_NUM>=0) {Usart_SendByte(USART1,'9');Start_Xue_Xi_falg[0]++;
        delay_5ms(10000);Usart_SendByte(USART1,'1');}//delay_5ms(2000);}    //����9����ʱ5sѧϰ����1
        if(!Start_Xue_Xi_falg[1] && TUNEM180_NUM>=2) {Usart_SendByte(USART1,'9');Start_Xue_Xi_falg[1]++;}
        if(!Start_Xue_Xi_falg[2] && TUNEM180_NUM>=4) {Usart_SendByte(USART1,'9');Start_Xue_Xi_falg[2]++;}
        if(!Start_Xue_Xi_falg[3] && TUNEM180_NUM>=6) {Usart_SendByte(USART1,'9');Start_Xue_Xi_falg[3]++;}
        if(!Start_Xue_Xi_falg[4] && TUNEM180_NUM>=8) {Usart_SendByte(USART1,'9');Start_Xue_Xi_falg[4]++;}
}
// ��Ҫ��ǰ����  1��ʼʶ�� 0����ʶ��
// �����Ѿ�֪��openmv�ᷢ�� l�� r��; 
// �����жϽ���
 
int Cstate = 0;      // ״̬
int CT_LINE = 0;     // ��¼����ʶ��T
//  ���Ʊ�־ ����ͣ
int Cstop_flag = 1;
int Cturn_left = 0;
int Cturn_right = 0;
// ����·�߼�¼
int Cback_flagl[4] = {1,1,0,0};
int Cback_flagr[4] = {0};
// ģ��ֹͣ
int Cmoni_falg = 0;
   void Test3(void (*CallBack)(void))
{
    if(Cstop_flag)  STOP();
    else    Control3(CallBack);
}


void Control3(void (*CallBack)(void))
{
//    printf("state:");
//    pint(Cstate);
//    printf("line:");
//    pint(CT_LINE);
    
    if(Cstate == 0)
    {
        FrTurnC();
        if(CT_LINE == 2)  CStart_Camera1();
        if(CT_LINE == 3)  CStart_Camera2();
        if(Cmoni_falg) //ģ��ѭ����ʱ 
        {
            if(FindYinYing())    {STOP();Cmoni_falg = 0;Cstop_flag = 1;LED_R_ON;CallBack();while(YOU_WU_PIN);CallBack();LED_R_OFF;Cstop_flag = 0;Cstate = 255;}
        }
        //���
        else if(FIND_T) Cstate = 1;
        xunji(TARV);    
    } 
    if(Cstate == 1)
    {
       if(OUT_T)
       {
           CT_LINE++;   // ��¼���˼���·��
           if(CT_LINE == 3 || CT_LINE == 4) Cstate = 2;  //����·��һ��
           else Cstate = 0;  //����·��һ��
       }
    }
    if(Cstate == 2)
    {
        if(Cturn_left)
        {
            Cback_flagl[CT_LINE - 1] = 1;
            Turn_Angle_ChaShu(-angle_90); 
        }
        else if(Cturn_right)
        {
            Cback_flagr[CT_LINE - 1] = 1;
            Turn_Angle_ChaShu(angle_90); 
        }
        Cstate = 0;
        if(CT_LINE == 4) {Cmoni_falg = 1;TIM2_CLR;}
    }
    
    
    //���� 
    if(Cstate == 255)  {Turn_Angle_LED_YUN();Cstate = 10;}
    if(Cstate == 10)
    {  
        if(Cmoni_falg == 1) //ģ��ѭ����ʱ 
        {
            CJiangShu();//ȥ��*****
            if(FindYinYing())
            {
               CallBack();     // �����λص�
               STOP();
               LED_G_ON;
               Cstop_flag = 1;
               Cmoni_falg = 0;     
            }
        }
        else if(FIND_LT(CT_LINE)) Cstate = 11;     
        xunji(TARV);
    }	
    if(Cstate == 11)
    {
        if(OUT_LT(CT_LINE))  //������ǰ����
        {   
            if(CT_LINE<=2) {Cback_flagl[CT_LINE - 1] = 0;Cback_flagr[CT_LINE - 1] = 0;}    
            if(Cback_flagl[CT_LINE - 1])
            {
                Turn_Angle_ChaShu(angle_90); 
            }
            else if(Cback_flagr[CT_LINE -1])
            {
                Turn_Angle_ChaShu(-angle_90); 
            } 
            CT_LINE--; 
            if(CT_LINE == 0) {Cmoni_falg = 1;TIM2_CLR;} // �жϿ�������   **********  
            Cstate = 10;
        }   
    }  
}


// ״̬
int Bstate = 0;
// ��¼����ʶ��T
int BT_LINE = 0;
//  ���Ʊ�־ ����ͣ
int Bstop_flag = 1;
int Bturn_left = 0;  
int Bturn_right = 0;
// ����·�߼�¼
int Bback_flagl[4] = {0};
int Bback_flagr[4] = {0};
// ģ��ֹͣ
int Bmoni_falg = 0;

void Test2(void (*CallBack)(void))
{
    if(Bstop_flag)  STOP();
    else    Control2(CallBack);
}

u8 delay_bug_flag = 0;
void delay_bug(void)
{
    if(!delay_bug_flag){delay_5ms(150);delay_bug_flag++;}
}
void Control2(void (*CallBack)(void))
{
//    printf("state:");
//    pint(Bstate);
//    printf("line:");
//    pint(BT_LINE);
//    pint( (short)TIM2 -> CNT );
    
    if(Bstate == 0)
    {
        FrTurnB();
        if(BT_LINE == 1)  {BStart_Camera();}  //��һ��·�ڷ�ʶ��ָ��
        if(Bmoni_falg) //ģ��ѭ����ʱ 
        {
            BJiangShu();
            if(FindYinYing()) {STOP();Bmoni_falg = 0;CallBack();Bstop_flag = 1;LED_R_ON;while(YOU_WU_PIN);LED_R_OFF;Bstop_flag = 0;Bstate = 255;} //�ص�
        }
        //���
        else if(FIND_T) Bstate = 1;
        xunji(TARV);    
    } 
    if(Bstate == 1)
    {
       if(OUT_T)
       {
//           delay_bug(); // ��ʱ
           BT_LINE++;   // ��¼���˼���·��
           if(BT_LINE == 2) Bstate = 2;  //����·��һ��
           else Bstate = 0;  //����·��һ��
       }
    }
    if(Bstate == 2)
    {
        if(Bturn_left)
        {
            Bback_flagl[BT_LINE - 1] = 1;
            Turn_Angle_ChaShu(-angle_90); 
        }
        else if(Bturn_right)
        {
            Bback_flagr[BT_LINE - 1] = 1;
            Turn_Angle_ChaShu(angle_90); 
        }
        Bstate = 0;
        if(BT_LINE == 2) {Bmoni_falg = 1;TIM2_CLR;}// �жϿ�������
    }
    
    
    //����
    if(Bstate == 255){CallBack(); Turn_Angle_LED_YUN(); Bstate = 10;}
    if(Bstate == 10)
    {  
        if(Bmoni_falg == 1)
        {
           BJiangShu2(); 
           if(FindYinYing())
           {  
                STOP();
                LED_G_ON;
                Bstop_flag = 1;
                Bmoni_falg = 0;
           } 
        }
        else if(FIND_T) {Bstate = 11;}     
        xunji(TARV);
    }	
    if(Bstate == 11)
    {
        if(OUT_T)
        {    
            if(Bback_flagl[BT_LINE - 1])
            {
                Turn_Angle_ChaShu(angle_90); 
            }
            else if(Bback_flagr[ BT_LINE -1])
            {
                Turn_Angle_ChaShu(-angle_90); 
            } 
            BT_LINE--;  
            if(BT_LINE == 0) {Bmoni_falg = 1;CallBack();TIM2_CLR;} // �жϿ�������   ********** 
            Bstate = 10;
        }
        
    }  
}



int Astate = 0;       // ״̬
int AT_LINE = 0;      // ��¼����ʶ��T

int Astop_flag = 1;   //  ���Ʊ�־ ����ͣ
int Aturn_left = 0;  
int Aturn_right = 0;
// ����·�߼�¼
int Aback_flagl[4] = {0};
int Aback_flagr[4] = {0};
// ģ��ֹͣ
int Amoni_falg = 0;


void Test1(void (*CallBack)(void))
{
    if(Astop_flag)   STOP();
    else             Control1(CallBack);
}
void Control1(void (*CallBack)(void))
{
//    printf("Astate:");
//    pint(Astate);
//    printf("Aline:");
//    pint(AT_LINE);
    
    if(Astate == 0)
    {
        FrTurnA();
        if(Amoni_falg) //ģ��ѭ����ʱ 
        {
            if( FindYinYing())   {STOP();Amoni_falg = 0;CallBack();Astop_flag = 1;LED_R_ON;while(YOU_WU_PIN);LED_R_OFF;Astop_flag = 0;Astate = 255;} //�ص�
        }
        //���
        else if(FIND_T)  Astate = 1;
        xunji(TARV);    
    } 
    if(Astate == 1)
    {
       if(OUT_T)
       {
           AT_LINE++;   // ��¼���˼���·��
           if(AT_LINE == 1) Astate = 2;  //����·��һ��
           else Astate = 0;  //����·��һ��
       }
    }
    if(Astate == 2)
    {
        if(Aturn_left)
        {
            Aback_flagl[AT_LINE - 1] = 1;
            Turn_Angle_ChaShu(-angle_90); 
        }
        else if(Aturn_right)
        {
            Aback_flagr[AT_LINE - 1] = 1;
            Turn_Angle_ChaShu(angle_90); 
        }
        Astate = 0;
        if(AT_LINE == 1) {Amoni_falg = 1;TIM2_CLR;} // �жϿ�������
    }
    
    
    
    //����
    if(Astate == 255){Turn_Angle_LED_YUN(); Astate = 10;}
    if(Astate == 10)
    {  
        if(Amoni_falg == 1) // �жϿ�������
        {
            if(FindYinYing())
            {
                STOP();
                LED_G_ON;  
                Astop_flag = 1;                
                Amoni_falg = 0;               
            }
        }
        else if(FIND_T) Astate = 11;     
        xunji(TARV);
    }	
    if(Astate == 11)
    {
        if(OUT_T)
        {    
            if(Aback_flagl[AT_LINE - 1])
            {
                Turn_Angle_ChaShu(angle_90); 
            }
            else if(Aback_flagr[AT_LINE - 1])
            {
                Turn_Angle_ChaShu(-angle_90); 
            } 
            AT_LINE--;
            if(AT_LINE == 0)   {Amoni_falg = 1;TIM2_CLR;} // �жϿ�������   **********         
            Astate = 10;
        }   
    }  
}



//*****************************����45************************************//
u8 Commu_RX = 0; //�жϽ��ձ���
//�������������
void Commu_Fun(u8 ch)
{
    Usart_SendByte(USART2,ch);
}

//����4 ���㺯��  һ��
u8 Tsak_4_Clear_flag = 0;
void Tsak_4_Clear(void)
{
    if(!Tsak_4_Clear_flag){Task_Clear();Tsak_4_Clear_flag++;}
}
//����4 �ص�����
u8 Test4_Back_flag = 0; 
void Test4_Back(void)
{
    // ���� 1��asscii  Bturn_left ��־
    if(Test4_Back_flag == 0)        
    {
        if(Bturn_left == 1) Commu_Fun('a');
        else                Commu_Fun('b'); 
    } //С��1���ﲡ����С��2����ȥ���ϵ�
    // else ����ִ��
    else if(Test4_Back_flag == 1)   {Commu_Fun('c');} //С��1�ص�ҩ����С��2���� ���� ȥ���没��
    else if(Test4_Back_flag == 2)   {Commu_Fun('j');} //����
    Test4_Back_flag++;
}

//����4
void Test4(void)
{
    if(Bstop_flag)  STOP();
    else            Test2(Test4_Back);
}   
 
//*************************************************************************//

//*************************************����5*******************************//

//����4 ���㺯��  һ��
u8 Tsak_5_Clear_flag = 0;
void Tsak_5_Clear(void)
{
    if(!Tsak_5_Clear_flag){Task_Clear();Tsak_5_Clear_flag++;}
}

//����4 �ص�����X
u8 Test5_Back_flag = 0; 
void Test5_Back(void)
{
    if(Test5_Back_flag == 0)       {Commu_Fun('d');}         // abc   d��car2��������ͷ
    else if(Test5_Back_flag == 1)  {Commu_Fun('e');}         // car2  car1����car2ȥ����
    else if(Test5_Back_flag == 2)  {Commu_Fun('f');}         // car2  car1�ص�ҩ��,car2ȥ����
    
    Test5_Back_flag++;
}

void Test5(void)
{
    if(Cstop_flag)  STOP();
    else            Test3(Test5_Back);
}






//*************************************************************************//

// ����45ר�ú���
void Task_Clear(void)
{
    Bstate = 0;
    BT_LINE = 0;
    Bstop_flag = 0;
    Bturn_left = 1;  
    Bturn_right = 0;
    for(int i=0;i<4;i++){Bback_flagl[i] = 0; Bback_flagr[i] = 0;}
    Bmoni_falg = 0;
    
    Astate = 0;
    AT_LINE = 0;
    Astop_flag = 0;
    Aturn_left = 1;  
    Aturn_right = 0;
    for(int i=0;i<4;i++){Aback_flagl[i] = 0; Aback_flagr[i] = 0;}
    Amoni_falg = 0;
    
    Cstate = 0;
    CT_LINE = 0;
    Cstop_flag = 0;
    Cturn_left = 0;  
    Cturn_right = 1;
    for(int i=0;i<4;i++){Cback_flagl[i] = 0; Cback_flagr[i] = 0;}
    Cback_flagl[0] = 1;  //ע��
    Cback_flagl[1] = 1;
    Cmoni_falg = 0;
    
    CStart_Camera1_falg[1] = 0;  //��ʶ���ź�3 1
    CStart_Camera1_falg[0] = 0;  //��ʶ���ź�3 2
    BStart_Camera_flag = 0;      //��ʶ���ź�2 1
    
    delay_bug_flag = 0;
    FrTurn_flagA = 0;    //��ͷת��
    FrTurn_flagB = 0;
    FrTurn_flagC = 0;
    BJiangShu_flag = 0;
    BJiangShu2_flag = 0;
    CJiangShu_flag = 0;
}
