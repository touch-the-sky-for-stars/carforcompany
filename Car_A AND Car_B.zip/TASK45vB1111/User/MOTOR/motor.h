#ifndef __MOTOR_H
#define __MOTOR_H
#include "main.h"  

#define STYB_GPIO_PORT    		GPIOA		                /* GPIO�˿� */
#define STYB_GPIO_CLK 	    	RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define STYB_GPIO_PIN			GPIO_Pin_15

#define MOTORA_GPIO_PORT    	GPIOB		              
#define MOTORA_GPIO_CLK 	    RCC_APB2Periph_GPIOB		
#define MOTORA_GPIO_PIN			GPIO_Pin_0|GPIO_Pin_1			        

#define MOTORB_GPIO_PORT    	GPIOA			            
#define MOTORB_GPIO_CLK 	    RCC_APB2Periph_GPIOA		
#define MOTORB_GPIO_PIN			GPIO_Pin_11|GPIO_Pin_12			        

#define            MOTOR_TIM                   TIM4
#define            MOTOR_TIM_APBxClock_FUN     RCC_APB1PeriphClockCmd
#define            MOTOR_TIM_CLK               RCC_APB1Periph_TIM4
// TIM3 ����Ƚ�ͨ��3 4
#define            MOTOR_TIM_CH3_GPIO_CLK      RCC_APB2Periph_GPIOB
#define            MOTOR_TIM_CH3_PORT          GPIOB
#define            MOTOR_TIM_CH3_PIN           GPIO_Pin_8
#define            MOTOR_TIM_CH4_GPIO_CLK      RCC_APB2Periph_GPIOB
#define            MOTOR_TIM_CH4_PORT          GPIOB
#define            MOTOR_TIM_CH4_PIN           GPIO_Pin_9

#define MOTOR_ON 	GPIO_SetBits(STYB_GPIO_PORT,STYB_GPIO_PIN);
#define MOTOR_OFF 	GPIO_ResetBits(STYB_GPIO_PORT,STYB_GPIO_PIN);


#define PWMA   TIM4->CCR4  //PB9
#define PWMB   TIM4->CCR3  //PB8
#define AIN2   PBout(0)
#define AIN1   PBout(1)
#define BIN1   PAout(11)
#define BIN2   PAout(12)

void STOP(void);
int myabs(int a);
void Set_Pwm(int moto1,int moto2);
void MOTOR_GPIO_Config(void);
void MOTOR_PWM_Init(u16 arr,u16 psc);

#endif //__MOTOR_H
