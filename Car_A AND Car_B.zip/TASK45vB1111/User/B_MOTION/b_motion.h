#ifndef __B_MOTION_H
#define __B_MOTION_H
#include "main.h"  

#define  SENSOR_L3 PBin(13)
#define  SENSOR_L2 PBin(5)
#define  SENSOR_L1 PAin(4)
#define  SENSOR_L0 PAin(5)

#define  SENSOR_R0 PAin(8)
#define  SENSOR_R1 PBin(14)
#define  SENSOR_R2 PBin(12)
#define  SENSOR_R3 PBin(15)

typedef struct{
    float kp;
    float ki;
    float kd;
    float INTER_MAX;
    
    float err0;
    float err1;
    float inter;
}PID_Typedef;

extern const int angle_90;
extern const int angle_yiying;   //����СһЩ
extern int TARV;                 // ѭ��ģ�� ָ���ٶ�
extern const int BACK_V;         // ƫ���޶��ع��ٶ�
extern PID_Typedef pid_light;

extern u8 FrTurn_flagA;          //��ͷת��
extern u8 FrTurn_flagB;
extern u8 FrTurn_flagC;

extern u8 BJiangShu_flag;
extern u8 BJiangShu2_flag;
extern u8 CJiangShu_flag;

extern u8 CStart_Camera1_falg[2];  //��ʶ���ź�3 1
extern u8 BStart_Camera_flag;      //��ʶ���ź�2 1

//************************��·������*******************************//
#define  LINE  1
#define  OUT   0
#define     FIND_T              (SENSOR_L1 + SENSOR_L0 + SENSOR_R0+SENSOR_R1 >= 4)
//#define     OUT_T               (SENSOR_L1 == OUT || SENSOR_L0 == OUT || SENSOR_R0 == OUT || SENSOR_R1 == OUT)
#define     OUT_T               (SENSOR_L1+SENSOR_L0+SENSOR_R0+SENSOR_R1+SENSOR_L3+SENSOR_L2+SENSOR_R2+SENSOR_R3 <= 2)
#define     YIN_YING_YU_ZHI     3  // 3 4 ԽСԽ׼ ,̫С���������Ӱǰ���Ǹ�T·�ڹ����ص�
//*******************************************************************//
int FindYinYing(void);
int FIND_LT(int line);
int OUT_LT(int line);

void xunji(int var_v);                  // ���ٶ�
int Process_Lightb_Best(void);
PID_Typedef* PID_Init(PID_Typedef* pid,float kp,float ki,float kd,float INTER_MAX);
float Cal_PID(PID_Typedef* pid,float sensor,float target);
void Turn_Angle_ChaShu(float angle);    // ���ٵ��� 
void Turn_Angle_Yuan(float angle);      // ���ٵ���
void Turn_Angle_LED_YUN(void);          // ��Ӱת��

void FrTurnA(void);
void FrTurnB(void);
void FrTurnC(void);
void BJiangShu(void);
void BJiangShu2(void);
void CJiangShu(void);


void Start_Xue_Xi(void);
void CStart_Camera1(void);
void CStart_Camera2(void);
void BStart_Camera(void);
void Start_Camera(void);
void Stop_Camera(void);


#endif //__CONTROL_H
