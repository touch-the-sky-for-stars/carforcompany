#include "usart1.h"

u8 Uart1Rx = 0;
u8 rx_flag = 0;
int rxnum = 1;

void ADEBUG_USART_IRQHandler(void)
{
    USART_ClearFlag(USART1,USART_FLAG_TC);
	if(USART_GetITStatus(USART1,USART_IT_RXNE) != RESET) //���յ�����
	{	  
		Uart1Rx = USART_ReceiveData(USART1); 
        
//        if(Uart1Rx == 'L')  {  Cturn_left = 1;Cturn_right = 0;}
//        else if(Uart1Rx == 'R')  {Cturn_left = 0;Cturn_right = 1;}
//          printf("%c",Uart1Rx);  

          if(TUNEM180_NUM == 4 || TUNEM180_NUM == 8)
          {
             if(rxnum % 2 == 0)
             {                 
                if(Uart1Rx == 'L' || Uart1Rx == 'R') 
                {
                    Cturn_left = 1;
                    Cturn_right = 0;
                }
             }
             else
             {
                 if(Uart1Rx == 'L')         {Cturn_left = 1;Cturn_right = 0;}
                 else if(Uart1Rx == 'R')    {Cturn_left = 0;Cturn_right = 1;}
                 
             }
          }
          
          
          else 
          {
              if(Uart1Rx == 'L') {Aturn_left = 1;Bturn_left = 1;Aturn_right = 0;Bturn_right = 0;}  
              else if(Uart1Rx == 'R') {Aturn_left = 0;Bturn_left = 0;Aturn_right = 1;Bturn_right = 1;}  
                          
          }
         
        rx_flag = 1;
	}  	
}

static void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_InitStructure.NVIC_IRQChannel = ADEBUG_USART_IRQ;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

void USART1_Init(u32 bund)
{
	 
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;

	ADEBUG_USART_GPIO_APBxClkCmd(ADEBUG_USART_GPIO_CLK, ENABLE);
	ADEBUG_USART_APBxClkCmd(ADEBUG_USART_CLK, ENABLE);

	// ��USART Tx��GPIO����Ϊ���츴��ģʽ
	GPIO_InitStructure.GPIO_Pin = ADEBUG_USART_TX_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(ADEBUG_USART_TX_GPIO_PORT, &GPIO_InitStructure);

  // ��USART Rx��GPIO����Ϊ��������ģʽ
	GPIO_InitStructure.GPIO_Pin = ADEBUG_USART_RX_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(ADEBUG_USART_RX_GPIO_PORT, &GPIO_InitStructure);
	// �����ж����ȼ�����
	
	NVIC_Configuration();
	// ���ò�����
	USART_InitStructure.USART_BaudRate = bund;
	// ���� �������ֳ�
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	// ����ֹͣλ
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	// ����У��λ
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	// ����Ӳ��������
	USART_InitStructure.USART_HardwareFlowControl = 
	USART_HardwareFlowControl_None;
	// ���ù���ģʽ���շ�һ��
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	// ��ɴ��ڵĳ�ʼ������
	USART_Init(ADEBUG_USARTx, &USART_InitStructure);
	
	
	// ʹ�ܴ��ڽ����ж�
	USART_ITConfig(ADEBUG_USARTx, USART_IT_RXNE, ENABLE);		
	// ʹ�ܴ���
	USART_Cmd(ADEBUG_USARTx, ENABLE);	    
}



