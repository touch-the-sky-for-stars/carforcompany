#ifndef __DELAY_H
#define __DELAY_H 			   
#include "main.h"  

void Delay_Init(void);
void delay_msx(u16 nms);//ע����ʱ��Χ������1786
void delay_us(u32 nus); 
void delay_ms(u16 nms);
 
//void SysTick_Init(void);
//void Delay_us(__IO u32 nTime);
//#define Delay_ms(x) Delay_us(100*x)	 //��λms

//void SysTick_Delay_Us( __IO uint32_t us);
//void SysTick_Delay_Ms( __IO uint32_t ms);

#endif





























