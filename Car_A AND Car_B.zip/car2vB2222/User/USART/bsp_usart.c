#include "bsp_usart.h"

u8 Usart2_Receive;
extern u8 Commu_RX; //�жϽ��ձ��� 
void DEBUG_USART_IRQHandler(void)
{	
	USART_ClearFlag( USART2, USART_FLAG_TC );
	if(USART_GetITStatus(DEBUG_USARTx, USART_IT_RXNE) != RESET) //���յ�����
	{	  
		Usart2_Receive = USART_ReceiveData(DEBUG_USARTx);
                         
        // ����car1 ����ת��־ ���ǵķ���
        if(Usart2_Receive == 'a') {Bturn_left = 0;Bturn_right = 1;Commu_RX = Usart2_Receive;}      // a��
        else if(Usart2_Receive == 'b'){Bturn_left = 1;Bturn_right = 0;Commu_RX = Usart2_Receive;}  // b��
        
        else if(Usart2_Receive == 'c'){Commu_RX = Usart2_Receive;}     //����
        else if(Usart2_Receive == 'j'){Commu_RX = Usart2_Receive;}     // ����
        
        else if(Usart2_Receive == 'd'){Start_Xue_Xi();}  //��ʼѧϰ
        else if(Usart2_Receive == 'e'){Commu_RX = Usart2_Receive;} //ȥ����
        else if(Usart2_Receive == 'f'){Commu_RX = Usart2_Receive;} //car2����
        
//		APP_PID(Usart2_Receive); //����и��ӵ�Э�飬С��ͨ�Ų������
	}  						
}


void APP_Show(void)
{    
	if(PID_Send==1)//����PID����
	{
		printf("{C%d:%d:%d:%d:%d:%d:%d:%d:%d}$",(int)(0),(int)(0),(int)(0),0,0,0,0,0,0);
		printf("show");
		PID_Send=0;	
	}	
}

static void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_InitStructure.NVIC_IRQChannel = DEBUG_USART_IRQ;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}


void USART_Config(u32 bund)
{
	 
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	DEBUG_USART_GPIO_APBxClkCmd(DEBUG_USART_GPIO_CLK, ENABLE);
	DEBUG_USART_APBxClkCmd(DEBUG_USART_CLK, ENABLE);
    
	GPIO_InitStructure.GPIO_Pin = DEBUG_USART_TX_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DEBUG_USART_TX_GPIO_PORT, &GPIO_InitStructure);
    
	GPIO_InitStructure.GPIO_Pin = DEBUG_USART_RX_GPIO_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(DEBUG_USART_RX_GPIO_PORT, &GPIO_InitStructure);
	
	NVIC_Configuration();
	USART_InitStructure.USART_BaudRate = bund;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = 
	USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(DEBUG_USARTx, &USART_InitStructure);
	USART_ITConfig(DEBUG_USARTx, USART_IT_RXNE, ENABLE);		
	USART_Cmd(DEBUG_USARTx, ENABLE);	    
}

/*****************  ����һ���ֽ� **********************/
void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch)
{
	USART_SendData(pUSARTx,ch);
	/* �ȴ��������ݼĴ���Ϊ�� */
	while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);	
}

/****************** ����8λ������ ************************/
void Usart_SendArray( USART_TypeDef * pUSARTx, uint8_t *array, uint16_t num)
{
  uint8_t i;
	
	for(i=0; i<num; i++)
  {
	    Usart_SendByte(pUSARTx,array[i]);	
  }
	/* �ȴ�������� */
	while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TC)==RESET);
}

/*****************  �����ַ��� **********************/
void Usart_SendString( USART_TypeDef * pUSARTx, char *str)
{
	unsigned int k=0;
  do 
  {
      Usart_SendByte( pUSARTx, *(str + k) );
      k++;
  } while(*(str + k)!='\0');
  /* �ȴ�������� */
  while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TC)==RESET)
  {}
}

/*****************  ����һ��16λ�� **********************/
void Usart_SendHalfWord( USART_TypeDef * pUSARTx, uint16_t ch)
{
	uint8_t temp_h, temp_l;
	
	/* ȡ���߰�λ */
	temp_h = (ch&0XFF00)>>8;
	/* ȡ���Ͱ�λ */
	temp_l = ch&0XFF;
	
	/* ���͸߰�λ */
	USART_SendData(pUSARTx,temp_h);	
	while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);
	
	/* ���͵Ͱ�λ */
	USART_SendData(pUSARTx,temp_l);	
	while (USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);	
}

///�ض���c�⺯��printf�����ڣ��ض�����ʹ��printf����
int fputc(int ch, FILE *f)
{
		/* ����һ���ֽ����ݵ����� */
		USART_SendData(DEBUG_USARTx, (uint8_t) ch);
		
		/* �ȴ�������� */
		while (USART_GetFlagStatus(DEBUG_USARTx, USART_FLAG_TXE) == RESET);		
	
		return (ch);
}

///�ض���c�⺯��scanf�����ڣ���д����ʹ��scanf��getchar�Ⱥ���
int fgetc(FILE *f)
{
		/* �ȴ������������� */
		while (USART_GetFlagStatus(DEBUG_USARTx, USART_FLAG_RXNE) == RESET);

		return (int)USART_ReceiveData(DEBUG_USARTx);
}

void pint(int num)
{
    printf("%d \n",num);
}

void pfloat(float num)
{
    printf("%5.2f \n",num);
}

u8 PID_Send = 0;
u8 Flash_Send = 0;
void APP_PID(u8 USART_Receive)
{
         static u8 Flag_PID,i,j,Receive[50];
         static float Data;
         //PID ����
         if(USART_Receive==0x7B) Flag_PID=1;   //APP����ָ�� ��ʼλ
         if(USART_Receive==0x7D) Flag_PID=2;   //APP����ָ�� ֹͣλ

         if(Flag_PID==1)  //�ɼ����� һ�� 0 1 2 3     4 5 ������
         {
            Receive[i]=USART_Receive;
            i++;
         }
         if(Flag_PID==2)  //��������  0x7D ������  0 - 7         i = 8
         {
            if(Receive[3]==0x50) 	 
                PID_Send=1;
            else if(Receive[3]==0x57) 	
                Flash_Send=1;
            else if(Receive[1]!=0x23) 
            {								
                for(j=i;j>=4;j--)   // j: 8 7 6 5 4 �ȸߺ��
                {
                    Data+=(Receive[j-1]-48)*pow(10,i-j);   //r7*1 + r6*10 + r5*100 + r4*1000 + r3*10000
                }
                switch(Receive[1])
                {
                    case 0x30:  pid_light.kp=Data/1000.0f;break;
                    case 0x31:  pid_light.ki=Data/10000.0f;break;
                    case 0x32:  pid_light.kd=Data/1000.0f;break;
                    extern int v_t;
                    case 0x33:  v_t = Data/10.0f; break;
                    case 0x34:  break; //Ԥ��
                    case 0x35:  break; //Ԥ��
                    case 0x36:  break; //Ԥ��
                    case 0x37:  break; //Ԥ��
                    case 0x38:  break; //Ԥ��
                }
            }				 
            Flag_PID=0;
            i=0;
            j=0;
            Data=0;
            memset(Receive, 0, sizeof(u8)*50);//��������
         }  
}
