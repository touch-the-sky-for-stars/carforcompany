#include "main.h"
//  a9 tx    a10 rx
//  3  rx    10  tx 

//  Astop_flag || Commu_RX �����˶�
//  �Ż���
/*  1 �޸��˲�������ʱ
    2 FindYinYing()���������   *JiangShu*()���� TIM2->CNT = 0;
*/
          
volatile uint32_t time = 0;
int _5msfalg = 0;
int v_t = 2500;     // APP���ٶ�

int main(void)
{	
	JTAG_Set(SWD_ENABLE);//����JTAG
	MY_NVIC_PriorityGroupConfig(2);
	Delay_Init();		//��ʱ������ʼ��
	ADVANCE_TIM_Init();	//TIM1��ʼ��
	Encoder_Init_TIM2();Encoder_Init_TIM3();
	USART_Config(9600);		//USART2 115200
    USART1_Init(115200);      // USART1 115200
	MOTOR_GPIO_Config();//���GPIO����
	MOTOR_PWM_Init(7199,0); //���PWM��ʼ��  10KHZ
    LED_Init();
    PID_Init(&pid_light,30,0.02,20,10000);    //PID_Init(&pid_light,30,0.02,20,10000);     
//	Usart_SendString( DEBUG_USARTx," DEBUG ");
	MOTOR_ON
    
    Astop_flag = 0;
    Aturn_right = 1;
    Aturn_left = 0;
    
    Bstop_flag = 0;
    Bturn_right = 1;
    Bturn_left = 0;
    
    Cstop_flag = 0;
    Cturn_right = 1;  //Ĭ�ϲ����Ըı�
    Cturn_left =  0;

    delay_5ms(100);
    
    
//    LED_R_ON;
//    LED_Y_ON;
//    while(1); 
//    Turn_Angle_ChaShu(38);
//    Set_Pwm(4000,2000);  

	while(1)
	{ 
        
        if(_5msfalg == 1)
        {    
//             xunji(v_t); 
            
//             if(KAISHI)  Test4(kong);
//             Test5(); 
            
              // ��һ��5sѧϰ  3��ģ��ʶ��
              if(TUNEM180_NUM<2 && YOU_WU_PIN)                                  Test4(kong);
              else if(TUNEM180_NUM<4 && TUNEM180_NUM >= 2 && MEI_WU_PIN)        {Test5();}     
              else                                                              STOP(); 
              
              if(TUNEM180_NUM == 2 && MEI_WU_PIN)                               LED_R_OFF; //Ϩ���4�ʵĵ�  
              
              
//              pint(TUNEM180_NUM);
             _5msfalg = 0;
        }
        
        
        
		if(time%100==0)//ÿ�뷢��һ����Ϣ
		{
           
//			printf("times:    %d",time);
//			printf("MOTO1: %d \t\t",Moto1);printf("MOTO2: %d \r\n",Moto2);
//			printf("motor_L: %d \t\t",motor_L);printf("motor_R: %d \r\n",motor_R);
            //�����ǰ�������ҷ�			
//		    printf("Encoder_L:  %d \t\t",(short)TIM2 -> CNT);printf("Encoder_R:  %d \r\n",(short)TIM3 -> CNT);
//            
//          printf("   SENSOL3: %d",SENSOR_L3);
//			printf("   SENSOL2: %d",SENSOR_L2); 
//			printf("   SENSOL1: %d",SENSOR_L1);
//          printf("   SENSOL0: %d\r\n\n",SENSOR_L0);
//			printf("   SENSOR0: %d",SENSOR_R0);
//			printf("   SENSOR1: %d",SENSOR_R1);
//			printf("   SENSOR2: %d\r\n\n",SENSOR_R2);
//          printf("   SENSOR3: %d\r\n\n",SENSOR_R3);
            
//          printf("CCR3:  %d \t\t",TIM4->CCR3);printf("CCR4:  %d \r\n",TIM4->CCR4 );
						
		}		
	}	
}

