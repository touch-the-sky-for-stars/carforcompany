#ifndef __MAIN_H
#define __MAIN_H
#include "stm32f10x.h"
#include "stm32f10x_tim.h"

extern volatile uint32_t time; // ms ��ʱ���� 
extern u8 PID_Send;
//SYSTEM
#include "./SYSTEM/sys.h"
#include "./SYSTEM/delay.h"
#include "./TIMER/timer.h"
#include "./TIMER/AdvanceTim.h" 
#include "./USART/bsp_usart.h"

//USER
#include "./CONTROL/control.h"
#include "./MOTOR/motor.h"
#include "./ENCODER/encoder.h"
#include "./USART/usart1.h"
#include "./LED/led.h"
#include "./B_MOTION/b_motion.h"


#endif //__MAIN_H

