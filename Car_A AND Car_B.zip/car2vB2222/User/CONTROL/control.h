#ifndef __CONTROL_H
#define __CONTROL_H
#include "main.h"  
   
#define   TIM2_CLR               ( (TIM2->CNT) = 100 )
#define   TIM2_CLR_THS            2000*ENCODER_k 
#define   TIM2_UP_TO_STD         ( ((short)(TIM2->CNT)) > TIM2_CLR_THS + 100 )  //�̾���
#define   TIM2_BIRNAG_K           2.3f
#define   TIM2_BIRNAG            ( ((short)(TIM2->CNT)) > (TIM2_CLR_THS + 100)*TIM2_BIRNAG_K) //������

#define  TASK_KAIGUAN   PBin(4)
#define  KAIGUAN_ON     0
#define  KAIGUAN_OFF    1
#define  YOU_WU_PIN     TASK_KAIGUAN == KAIGUAN_ON
#define  MEI_WU_PIN     TASK_KAIGUAN == KAIGUAN_OFF
#define  KAISHI         ( YOU_WU_PIN && (TUNEM180_NUM % 2 == 0) || MEI_WU_PIN && (TUNEM180_NUM % 2 == 1) )

extern int TUNEM180_NUM;
extern int TARV;             // ѭ�� ǰ���ٶ�

extern int AT_LINE;      // ��¼����ʶ��T
extern int Astop_flag;   //  ���Ʊ�־ ����ͣ
extern int Aturn_left;  
extern int Aturn_right;
extern int Aback_flagl[4];
extern int Aback_flagr[4];

extern int BT_LINE;      // ��¼����ʶ��T
extern int Bstop_flag;   //  ���Ʊ�־ ����ͣ
extern int Bturn_left;  
extern int Bturn_right;
extern int Bback_flagl[4];
extern int Bback_flagr[4];

extern int CT_LINE;      // ��¼����ʶ��T
extern int Cstop_flag;   //  ���Ʊ�־ ����ͣ
extern int Cturn_left;  
extern int Cturn_right;
extern int Cback_flagl[4];
extern int Cback_flagr[4];


// ���÷�ʽ test3(function());
void Task_Clear(void);
void Control3(void (*CallBack)(void));
void Test3(void (*CallBack)(void));
void Control2(void (*CallBack)(void));
void Test4(void (*CallBack)(void));
void Control1(void (*CallBack)(void));
void Test1(void (*CallBack)(void));
void kong(void);
void Test5(void);

#endif //__CONTROL_H
