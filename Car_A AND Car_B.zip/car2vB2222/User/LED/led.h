#ifndef __LED_H
#define __LED_H
#include "main.h"  

#define LED_R_ON       PBout(11) = 0
#define LED_Y_ON       PBout(10) = 0

#define LED_R_OFF      PBout(11) = 1
#define LED_Y_OFF      PBout(10) = 1

void LED_Init(void);


#endif 
