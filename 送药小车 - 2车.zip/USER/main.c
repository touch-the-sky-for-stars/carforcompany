// PB10�Ǻ���Թܵ���������
#include "stm32f4xx.h"
#include "sys.h"
#include "delay.h"
#include "duoji.h"
#include "dianji.h"
#include "bluetooth.h"
#include "to_openmv.h"
#include "hongwai.h"
#include "usart.h"
#include "stdbool.h"
#include "led.h"



#define guangdian_IO PBin(10) //װ����ҩƷ��hongwai_IO = 0
#define Start 0
#define Turn_left 1
#define Turn_right 2
#define Stop 4
#define Wait 5
#define Slower 6
#define Faster 7
#define Forward 8
#define Backward 9
#define Back 10
#define xunji 11
#define Stoping 12
#define Fuwei 15
#define Finish 16
#define Zanwait 18

int j=0;
signed char bluetooth = 0;
uint16_t temp = 0;
char state = 0;
char next_state = 0;
char flag = 0; //�Ƿ��Ѿ�ʶ��Ҫȥ�Ĳ�����
signed char rec_flag = 0;
u16 openmv_rec[4] = {0};
signed char i = 0;
signed char task = 0;
uint8_t num=0;
uint8_t len;
int jieduan=0;
int xincheng[10]={0};
int jilu=0;
u8 huidu=0;
u8 uart_5_flag=0;
int shudu=500;
int tingzhi_flag=0;
int lukoujishu=0;
int tingzhilukou=0;
int qidong_flag=0;
void zuozhuanwan()
{											PFout(7)=1;
							PCout(5)=1;
							zhixing();
							delay_ms(200);
							stop();
							delay_ms(100);
							zuozhuan();
							stop();
							delay_ms(200);
							PCout(5)=1;
							PFout(7)=1;
//							if(jieduan==1)
//								if(jilu==3)
//								{
//								zhixing();
//								delay_ms(200);
//								}
							USART_SendData(UART5,'3');
		
}

void youzhuanwan()
{							
											PFout(7)=1;
							PCout(5)=1;
							zhixing();
							delay_ms(200);
							stop();
							delay_ms(100);
							youzhuan();
							stop();
							delay_ms(200);
							PCout(5)=1;
							PFout(7)=1;
//								if(jieduan==1)
//								if(jilu==3)
//								{
//								zhixing();
//								delay_ms(200);
//								}
							USART_SendData(UART5,'3');
	
}

void turn_r()
{
  //TIM_SetCompare1(TIM3, 88);
	  PFout(5) = 0;
    PFout(7) = 1;
	  PCout(4) = 1;
    PCout(5) = 0;
		Change_Target(465,430);
		delay_ms(900);
			stop();
//    delay_ms(800);
//		stop();
		
}

void shibieshuzhizhunbei()
{
	  PFout(5) = 1;
    PFout(7) = 0;
	  PCout(4) = 1;
    PCout(5) = 0;
		Change_Target(485,500);
	delay_ms(50);
			stop();
}
void uart_5_chuli()
{
	int pianzhuanjiaodu=0;
		switch(openmv_rec[1])
				{	
					case 0:
							flag=1;
							num=openmv_rec[2];
							LED1=0;
			//		USART_SendData(UART5,'3');
				//	zhixingguoluokou();
					  
						break;
						
					case 1:
						
							state = xunji;
							xincheng[jilu++]=1;
							//if(num>=3)
							//{
							PFout(7)=1;
							PCout(5)=1;
							//}
							zuozhuanwan();
						break;
					
					case 2:	

							state = xunji;
							xincheng[jilu++]=2;
							//if(num>=3)
							//{
								PFout(7)=1;
								PCout(5)=1;
							//}
							youzhuanwan();
						break;
					
					case 3:
							stop();
							if(jieduan==0)
							{
								lukoujishu++;
													
							switch(lukoujishu)
							{
								case 1:
											zhixingguoluokou();
											xincheng[jilu++]=3;
											USART_SendData(UART5,'3');
											break;
								
								case 2:
											
											zhixingguoluokou();
											xincheng[jilu++]=3;
											USART_SendData(UART5,'3');
											break;
								
								case 3:
											switch(tingzhilukou)
													{
														case 1:
															delay_ms(200);
															turn_r();
															stop();
															break;
														
														case 2:
															delay_ms(200);
															turn_r();
															stop();
															break;
														
														case 3:
															PFout(7)=1;
															PCout(5)=1;
															zhixing();
															delay_ms(200);
															stop();
															delay_ms(100);
															youzhuan();
															stop();
															delay_ms(200);
															PCout(5)=1;
															PFout(7)=1;
															delay_ms(200);
															xincheng[jilu++]=2;
															stop();
															break;
																						
														case 4:
															PFout(7)=1;
															PCout(5)=1;
															zhixing();
															delay_ms(200);
															stop();
															delay_ms(100);
															zuozhuan();
															stop();
															delay_ms(200);
															PCout(5)=1;
															PFout(7)=1;
															delay_ms(200);
															xincheng[jilu++]=1;
															stop();
															break;
														
														default:
															break;
													}
											state = xunji;
										break;

									default:
											stop();
									delay_ms(100);
									shibieshuzhizhunbei();
									USART_SendData(UART5,'2');
									while(USART_GetFlagStatus(UART5,USART_FLAG_TC)!=SET);//�ȴ����ͽ���
											break;
									
								}
							}
							else	if(jieduan==1)
							{			
										state = xunji;
										//PFout(7)=1;
										//PCout(5)=1;
										jilu--;
								switch(xincheng[jilu])
								{
									case 1:
//										PFout(7)=1;
//										PCout(5)=1;
//										zhixing();
//										delay_ms(100);
										stop();
										youzhuanwan();
										break;
									
									case 2:
//										PFout(7)=1;
//										PCout(5)=1;
//										delay_ms(100);
										stop();
										zuozhuanwan();
										break;
									
									case 3:
										zhixingguoluokou();
										USART_SendData(UART5,'3');
									
										break;
									
									default:
										break;
								}
								
								break;
							}
							else
							{
										jilu=2;
										PFout(7)=1;
										PCout(5)=1;
										zhixing();
										delay_ms(200);
										stop();
							if(tingzhilukou==1)
							{
								xincheng[1]=1;
								youzhuan();
							stop();
							delay_ms(200);
							PCout(5)=1;
							PFout(7)=1;
//								if(jieduan==1)
//								if(jilu==3)
//								{
//								zhixing();
//								delay_ms(200);
//								}
							USART_SendData(UART5,'3');
							}
							else
							{
								xincheng[1]=2;
									zuozhuan();
							stop();
							delay_ms(200);
							PCout(5)=1;
							PFout(7)=1;
//							if(jieduan==1)
//								if(jilu==3)
//								{
//								zhixing();
//								delay_ms(200);
//								}
							USART_SendData(UART5,'3');
							}
								
							break;
							
							}
								break;
					
						case 4:
							if(lukoujishu==4)
							{
								if(tingzhilukou==3)
								xincheng[2]=1;
								else
								xincheng[2]=2;

								lukoujishu=3;
								turn_r();
								PFout(7)=1;
								PCout(5)=1;
							}
							else
							{
								zhixingguoluokou();
								xincheng[jilu++]=3;
							}
							USART_SendData(UART5,'3');
							break;
						case 5:
							pianzhuanjiaodu=openmv_rec[2];
					//	printf("%d\n",pianzhuanjiaodu);
						if(pianzhuanjiaodu==52)
							Change_Target(485,420);
				else
							Change_Target(485-(pianzhuanjiaodu-52)*7,450+(pianzhuanjiaodu-52)*9);
						break;
				
						case 6:
							stop();
							LED1=0;
						if(tingzhi_flag>=1)
						{
							stop();
							state=Finish;
						}
						else
						{
						tingzhi_flag++;
							state=Wait;
						}
							break;
				}
}

void All_Init()
{	  
	//uart_init(115200);
    delay_init(168);
		LED_Init();
    hongwai_IO_Init();
    dianji_IO_Init();
    dianji_PWM_Init(1000-1, 84 - 1);
		bluetooth_U3_Init();
    openmv_U5_Init();
	//	Encoder_Init();
		LED1=1;
		//LED0=1;
}



int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
		//NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����

    All_Init();




		state=Start;
		PFout(5) = 0;
		PFout(7) = 1;
		PCout(4) = 0;
		PCout(5) = 1;	
//	Change_Target(485,500);
//	turn_r();
//	zhixing();
//	xiangzuo(200);
//	delay_ms(500);
//	turn_r();

//		TIM_SetCompare2(TIM1,50);	
//		TIM_SetCompare3(TIM1,50);	
//		TIM_SetCompare4(TIM1,50);	
//	Change_Target(50,50);
//	delay_ms(1000);
	//stop();

//	Change_Target(430,400);

    while (1)
    { 
			
	
        switch (state)
        {
        case Start:
            while(flag == 0); //�Ѿ�ʶ�𵽲�����
						
            while (flag == 1)
            {
							
                if (guangdian_IO == 1)
                {
										delay_ms(1000);
                    if (guangdian_IO == 1)
										{
												USART_SendData(USART3,'0');
												while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);
												state=xunji;
												LED1=1;	
												USART_SendData(UART5,'3');
                        break;
										}
                }
            }
            break;
						
				case xunji:
					if(qidong_flag==1)
					{					
					PFout(7) = 1;
					PCout(5) = 1;	
					USART_SendData(UART5,'3');
					qidong_flag=0;
					}
//						if(pianzhuanjiaodu==50)
//							Change_Target(530,500);
//				else
//							Change_Target(530-(pianzhuanjiaodu-50)*3,500+(pianzhuanjiaodu-50)*3);
				break;
						
				case Forward:
						zhixingguoluokou();
						if(jieduan==0)
							xincheng[jilu++]=8;
						USART_SendData(UART5,'3');
						break;
						
				
        case Turn_right:
						
            break; //���輱ת��1.5S�Ѿ�ת��ȥ�����������Ҫ����
        case Turn_left:

            break; //���輱ת��1.5S�Ѿ�ת��ȥ�����������Ҫ����
        case Wait:	
						while(1)
							{
									if (guangdian_IO == 0)
								{
										delay_ms(1000);
										if (guangdian_IO == 0)
										{
											state=xunji;
											jieduan=1;
											turn_r();
										//delay_ms(1200);
										//stop();
											delay_ms(200);
											PFout(7) = 1;
											PCout(5) = 1;	
											//flag = 0;
											if(jilu>=3)
													USART_SendData(UART5,'4');
											else
											USART_SendData(UART5,'3');
											
											break;
										}
								}
							}
					
            break;
						
        case Stoping:
            stop();
				USART_SendData(UART5,'4');
            break;
        case Finish:
            stop();
            state = Start;
            break;
        default:
            break;
        }
			}	
}
/* �������� */
// 2 che
void USART3_IRQHandler()
{
    if (USART_GetITStatus(USART3, USART_IT_RXNE)!=RESET)
    {
        bluetooth = USART_ReceiveData(USART3);
      
				
			switch(bluetooth)
			{
				case '0':                                                                                                                   
					if(tingzhilukou==1 || tingzhilukou==2)
					{
					jieduan=2;
					}
					qidong_flag=1;
					break; 
				
				case '1':
					tingzhilukou=1;
			
					break;
				
				case '2':
					tingzhilukou=2;
		
					break;
				
				case '3':
					tingzhilukou=3;
	
					break;
				
				case '4':
					tingzhilukou=4;
		
					break;
			
			}
			    USART_ClearITPendingBit(USART3, USART_IT_RXNE);
    }

}

/* openmv���� */
void UART5_IRQHandler()
{
	if (USART_GetITStatus(UART5, USART_IT_RXNE)!=RESET)
	{
		signed char temp = USART_ReceiveData(UART5);
		if (temp ==0x2C)
		{

				rec_flag = 1;
				i = 1;
		}
		else if (rec_flag == 1)
		{
				if (temp ==0x5B)
				{
						openmv_rec[i] = 0x5B;
		//				LED1=0;
						uart_5_chuli();
						rec_flag=0;

				}
				else
				{
						openmv_rec[i] = temp;
						i++;
				}

			}
		USART_ClearITPendingBit(UART5,USART_IT_RXNE);  	
	}
		
}



