#ifndef _HONGWAI_H
#define _HONGWAI_H

void hongwai_IO_Init();

#endif // !_HONGWAI_H