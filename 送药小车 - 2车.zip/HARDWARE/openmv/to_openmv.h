#ifndef _TO_OPENMV_H
#define _TO_OPENMV_H

signed char CharCon(signed char c[],signed char x);
void openmv_U5_Init();
void computer_U1_Init();

#endif // !_TO_OPENMV_H