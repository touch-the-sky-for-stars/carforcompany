#include "to_openmv.h"
#include "stm32f4xx.h"

/* openmv发送过来的字符串转换为数据:只保留整数，中间用小数点判断,函数返回值为0则数据格式出错*/
signed char CharCon(signed char c[],signed char x)
{
	int i = 0;
	int j = 0;	
	while(c[i] != '.') 
	{
		c[i] = c[i] - '0';
		i++;
	}
	j = i;
	if(c[0] == ('-'-'0'))
	{
		i = 4;
		c[0] = 0;
	}
	switch(i)
	{
		case 1:x = c[i-1];break;
		case 2:x = c[i-1] + 10*c[i-2];break;
		case 3:x = -(c[i-1] + 10*c[i-2]);break;
		case 4:x = -(c[j-1] + 10*c[j-2]);break;
		default:return 0;break;
	}
    return x;
}

/*openmv通信:USART5,所用引脚为PC12,PD2*/
void openmv_U5_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);  //使能GPIOC时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE); //使能USART5时钟

	//串口1对应引脚复用映射
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource12, GPIO_AF_UART5); //GPIOC12复用为USART5
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource2, GPIO_AF_UART5); //GPIOD2复用为USART5

	//USART1端口配置
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12; //GPIOc12与GPIOD2
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;			 //复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //速度50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;			 //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;			 //上拉
	GPIO_Init(GPIOC, &GPIO_InitStructure);					 //初始化PA9，PA10

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	//USART1 初始化设置
	USART_InitStructure.USART_BaudRate = 115200;										//波特率设置
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;						//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;							//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;								//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;					//收发模式
	USART_Init(UART5, &USART_InitStructure);										//初始化串口1

	USART_ITConfig(UART5, USART_IT_RXNE, ENABLE); //开启相关中断

	//Usart1 NVIC 配置
	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;		  //串口1中断通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; //抢占优先级3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		  //子优先级3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			  //IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);							  //根据指定的参数初始化VIC寄存器、

	USART_Cmd(UART5, ENABLE); //使能串口5
}

/* PA9,PA10 */
void computer_U1_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);  //使能GPIOA时钟
	RCC_APB1PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE); //使能USART2时钟

	//串口1对应引脚复用映射
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1); //GPIOA9复用为USART1
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1); //GPIOA10复用为USART1

	//USART1端口配置
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10; //GPIOA9与GPIOA10
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;			 //复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //速度50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;			 //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;			 //上拉
	GPIO_Init(GPIOA, &GPIO_InitStructure);					 //初始化PA9，PA10

	//USART1 初始化设置
	USART_InitStructure.USART_BaudRate = 9600;										//波特率设置
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;						//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;							//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;								//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;					//收发模式
	USART_Init(USART1, &USART_InitStructure);										//初始化串口1

	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); //开启相关中断

	//Usart1 NVIC 配置
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;		  //串口1中断通道
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; //抢占优先级3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		  //子优先级3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			  //IRQ通道使能
	NVIC_Init(&NVIC_InitStructure);							  //根据指定的参数初始化VIC寄存器、

	USART_Cmd(USART1, ENABLE); //使能串口1
}

