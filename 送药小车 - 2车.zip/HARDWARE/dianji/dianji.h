#ifndef _DIANJI_H
#define _DIANJI_H 

#include "sys.h"

void dianji_IO_Init();
void dianji_PWM_Init(u16 arr, u16 psr);
void TIM1_PWM_Init(u16 per,u16 psc);
void zhengzhuan(int len);
void fanzhuan(int len);
void set_speed(u16 speed);
void stop();
void zhixingguoluokou();
void zhixing();
void zuozhuan();
void youzhuan();
void xunji();
#endif // !_DIANJI_H