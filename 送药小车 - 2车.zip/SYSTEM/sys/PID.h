#ifndef _PID_H
#define _PID_H
#include "stm32f4xx.h"
#include "sys.h"
#include "delay.h"
#define     MODEL_P         1
#define     MODEL_PI        2
#define     MODEL_PID       3
#define     MODEL_PD        4
 
 
typedef struct
{
	  char dir;
	  u8 k;
    u8 choose_model;        
    u16 Tdata;    //�ж�PID���ڵ�û��
    float max;
		float min;//����޷�
	  float Sv;     //?????
    float Pv;        //???,???
    float Kp;        //????
    u16 T;      //PID????--????   
    float Ki;        //??????
    float Kd;       //????    
    float Ek;          //????
    float Ek_1;        //????
    float SEk;         //??????   
    float Iout;        //????
    float Pout;        //????    
    float Dout;        //????  
    float OUT0;        //�������
    float OUT;        //????????    
}PID;
 
extern PID pid; 
char PID_Calc(float Pv,float w); //pid����
void PID_Init(float p,float i);        //PID��ʼ��    
 
#endif